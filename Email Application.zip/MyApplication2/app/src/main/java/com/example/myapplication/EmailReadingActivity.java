package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EmailReadingActivity extends AppCompatActivity {

    private TextView emailFrom, emailTo, emailCc, emailSubject, emailBody;
    private Button editEmailButton, sendEmailButton;
    private DatabaseHelper dbHelper;
    private int emailId; // To hold the email ID for updating status

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_reading);

        dbHelper = new DatabaseHelper(this);

        // Initialize TextViews
        emailFrom = findViewById(R.id.email_from_reading);
        emailTo = findViewById(R.id.email_to_reading);
        emailCc = findViewById(R.id.email_cc_reading);
        emailSubject = findViewById(R.id.email_subject_reading);
        emailBody = findViewById(R.id.email_body_reading);
        editEmailButton = findViewById(R.id.edit_email_button);
        sendEmailButton = findViewById(R.id.send_email_button);

        // Get data from Intent
        Email email = (Email) getIntent().getSerializableExtra("email");
        emailId = getIntent().getIntExtra("email_ID", -1);

        // Set the data to TextViews
        emailFrom.setText("From: " + email.getFrom());
        emailTo.setText("To: " + email.getTo());
        emailCc.setText("CC: " + email.getCc());
        emailSubject.setText("Subject: " + email.getSubject());
        emailBody.setText(email.getBody());


        editEmailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // return to the previous activity
            }
        });

        sendEmailButton.setOnClickListener(view -> {
            if (sendEmail()) {
                finish(); // Close this activity
                // After successfully sending, create a new draft
                Intent newEmail = new Intent(EmailReadingActivity.this, EmailCompositionActivity.class);
                startActivity(newEmail); // Start a new email composition activity
            } else {
                // Show fail message
                Toast.makeText(this, "Email sending failed. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean sendEmail() {

        // logic to send the email

        // mark it as sent in the database
        boolean sent = dbHelper.updateEmailAsSent(emailId);
        // Optionally display a Toast message to confirm sending
        if (sent) {
            // Show success message
            Toast.makeText(this, "Email sent successfully!", Toast.LENGTH_SHORT).show();
            return true; // Assume sending was successful
        }
        return false;
    }
}