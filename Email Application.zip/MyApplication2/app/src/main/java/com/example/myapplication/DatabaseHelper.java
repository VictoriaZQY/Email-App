package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "emails.db";
    private static final String TABLE_NAME = "email_table";
    private static final String COL_ID = "ID"; // auto-incrementing id
    private static final String COL_FROM = "from_email";
    private static final String COL_TO = "to_email";
    private static final String COL_CC = "cc_email";
    private static final String COL_SUBJECT = "subject";
    private static final String COL_BODY = "body";
    private static final String COL_SENT = "is_sent"; // flag to mark if it's sent

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    // create the email table to remember all the emails
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_FROM + " TEXT, " +
                COL_TO + " TEXT, " +
                COL_CC + " TEXT, " +
                COL_SUBJECT + " TEXT, " +
                COL_BODY + " TEXT, " +
                COL_SENT + " INTEGER)";
        db.execSQL(createTable);
    }

    // upgrade versions
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Insert email information into the database
    public int insertData(String from, String to, String cc, String subject, String body, boolean isSent) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_FROM, from);
        contentValues.put(COL_TO, to);
        contentValues.put(COL_CC, cc);
        contentValues.put(COL_SUBJECT, subject);
        contentValues.put(COL_BODY, body);
        contentValues.put(COL_SENT, isSent ? 1 : 0);    // if sent, true; if not sent, false
        long result = db.insert(TABLE_NAME, null, contentValues);
        // if inserted successfully, return the email's ID
        return  (int) result;
    }

    // Retrieve saved email details by ID
    public Cursor getEmail(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        String getEmailByID = "SELECT * FROM " + TABLE_NAME + " WHERE ID = ?";
        return db.rawQuery(getEmailByID, new String[]{String.valueOf(id)});
    }


    // Get All Emails
    public Cursor getAllEmails() {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }

    // Update email to mark as sent
    public boolean updateEmailAsSent(int emailId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_SENT, 1); // Assuming sent status is an integer; update as per your schema
        int rowsAffected = db.update(TABLE_NAME, contentValues, COL_ID + " = ?", new String[]{String.valueOf(emailId)});
        return rowsAffected > 0; // Return true if at least one row was updated
    }

    // Delete email
    public void deleteEmail(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COL_ID + " = ?", new String[]{String.valueOf(id)});
    }
}