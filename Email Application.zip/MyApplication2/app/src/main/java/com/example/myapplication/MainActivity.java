package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button loginButton;
    private EditText ETusername, ETpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        loginButton = (Button) findViewById(R.id.loginButton);
        ETusername = findViewById(R.id.username);
        ETpassword = findViewById(R.id.password);

        loginButton.setOnClickListener(this::onClick);
    }

    private void onClick(View v) {
        String username = ETusername.getText().toString();
        String password = ETpassword.getText().toString();
        Intent toEmailCompositionIntent;
        String success = "Login successfully!";
        String fail = "Sorry, the account with this password was not found, please try again";

        // if the username is "zqy@simplemail.com" and password is "123456", then login
        if (username.equals("zqy@simplemail.com") && password.equals("123456")){
            // show some message to indicate that it works
            Toast.makeText(getApplicationContext(), success, Toast.LENGTH_SHORT).show();
            toEmailCompositionIntent = new Intent(MainActivity.this, EmailCompositionActivity.class);
            startActivity(toEmailCompositionIntent);
        } else {
            // show some message to indicate that it didn't works
            Toast toastCenter = Toast.makeText(getApplicationContext(), fail, Toast.LENGTH_SHORT);
            toastCenter.setGravity(Gravity.CENTER, 0 , 0);
            toastCenter.show();
        }
    }

}