package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

// If the emailId is -1, the activity operates in "create" mode.
//If emailId is valid, it operates in "edit" mode, allowing for the editing of the existing email data

public class EmailCompositionActivity extends AppCompatActivity {

    private EditText emailFrom, emailTo, emailCc, emailBcc, emailSubject, emailBody;
    private Button clearButton, previewButton;
    private DatabaseHelper dbHelper;
    private int emailId = -1; // To hold the email ID if editing a draft

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_composition);

        emailFrom = findViewById(R.id.email_from);
        emailTo = findViewById(R.id.email_to);
        emailCc = findViewById(R.id.email_cc);
        emailBcc = findViewById(R.id.email_bcc);
        emailSubject = findViewById(R.id.email_subject);
        emailBody = findViewById(R.id.email_body);
        clearButton = findViewById(R.id.clear_button);
        previewButton = findViewById(R.id.preview_button);

        dbHelper = new DatabaseHelper(this);

        //saveEmailDraft();

//
//        // if the email is newly created, load email data of its first version
//        Intent intent = getIntent();
//        if (intent.hasExtra("email_id") && emailId == -1) {
//            emailId = intent.getIntExtra("email_id", -1);
//            loadEmailData(emailId);
//        }


        // If editing an existing email, load its data
        if (emailId != -1) {
            loadEmailData(emailId);
        }


        // save as a draft if click the preview button
        previewButton.setOnClickListener(view -> {
            previewEmail();
        });

        // clear all if click the clear button
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearFields();
            }
        });
    }




    private void previewEmail() {
        saveEmailDraft();   // Save the draft

        Email email = new Email(
                emailFrom.getText().toString(),
                emailTo.getText().toString(),
                emailCc.getText().toString(),
                emailBcc.getText().toString(),
                emailSubject.getText().toString(),
                emailBody.getText().toString()
        );

        Intent intent = new Intent(this, EmailReadingActivity.class);
        intent.putExtra("email", email);
        intent.putExtra("email_ID", emailId);
        startActivity(intent);
    }


    // Clear everything
    private void clearFields() {
        emailFrom.setText("");
        emailTo.setText("");
        emailCc.setText("");
        emailBcc.setText("");
        emailSubject.setText("");
        emailBody.setText("");
    }



    @SuppressLint("Range")
    private void loadEmailData(int emailId) {
        Cursor cursor = dbHelper.getEmail(emailId);

        if (cursor != null && cursor.moveToFirst()) {
            emailFrom.setText(cursor.getString(cursor.getColumnIndex("from_email")));
            emailTo.setText(cursor.getString(cursor.getColumnIndex("to_email")));
            emailCc.setText(cursor.getString(cursor.getColumnIndex("cc_email")));
            emailSubject.setText(cursor.getString(cursor.getColumnIndex("subject")));
            emailBody.setText(cursor.getString(cursor.getColumnIndex("body")));
        }
        if (cursor != null) {
            cursor.close();
        }
    }



    private void saveEmailDraft() {
        String from = emailFrom.getText().toString();
        String to = emailTo.getText().toString();
        String cc = emailCc.getText().toString();
        String subject = emailSubject.getText().toString();
        String body = emailBody.getText().toString();

        // Save to database
        if (emailId != -1) {
            // Update the existing draft if we're editing if still editing a draft created
            updateEmailDraft(emailId, from, to, cc, subject, body);
        } else {
            // Otherwise, create a new draft
            emailId = dbHelper.insertData(from, to, cc, subject, body, false);
        }
    }

    private void updateEmailDraft(int emailId, String from, String to, String cc, String subject, String body) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("from_email", from);
        contentValues.put("to_email", to);
        contentValues.put("cc_email", cc);
        contentValues.put("subject", subject);
        contentValues.put("body", body);
        // Execute the update
        db.update("email_table", contentValues, "ID = ?", new String[]{String.valueOf(emailId)});
    }
}


