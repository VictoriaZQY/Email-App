/*
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class temp extends AppCompatActivity {

    private EditText emailFrom, emailTo, emailCc, emailSubject, emailBody;
    private Button previewButton, sendButton;
    private DatabaseHelper dbHelper;
    private int emailId = -1; // To hold the email ID if editing a draft  

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_composition);

        // Initialize views and DatabaseHelper  
        emailFrom = findViewById(R.id.email_from);
        emailTo = findViewById(R.id.email_to);
        emailCc = findViewById(R.id.email_cc);
        emailSubject = findViewById(R.id.email_subject);
        emailBody = findViewById(R.id.email_body);
        previewButton = findViewById(R.id.preview_button);
        sendButton = findViewById(R.id.send_button);

        dbHelper = new DatabaseHelper(this);

        // Load email data if coming from edit  
        Intent intent = getIntent();
        if (intent.hasExtra("email_id")) {
            emailId = intent.getIntExtra("email_id", -1);
            loadEmailData(emailId);
        }

        previewButton.setOnClickListener(view -> {
            saveEmailDraft();
            // Move to reading activity  
            Intent previewIntent = new Intent(this, EmailReadingActivity.class);
            previewIntent.putExtra("from", emailFrom.getText().toString());
            previewIntent.putExtra("to", emailTo.getText().toString());
            previewIntent.putExtra("cc", emailCc.getText().toString());
            previewIntent.putExtra("subject", emailSubject.getText().toString());
            previewIntent.putExtra("body", emailBody.getText().toString());
            startActivity(previewIntent);
        });

        sendButton.setOnClickListener(view -> {
            if (sendEmail()) {
                deleteDraft();
                finish(); // close the activity  
            }
        });
    }

    private void loadEmailData(int emailId) {
        Cursor cursor = dbHelper.getEmail(emailId);

        if (cursor.moveToFirst()) {
            emailFrom.setText(cursor.getString(cursor.getColumnIndex("from_email")));
            emailTo.setText(cursor.getString(cursor.getColumnIndex("to_email")));
            emailCc.setText(cursor.getString(cursor.getColumnIndex("cc_email")));
            emailSubject.setText(cursor.getString(cursor.getColumnIndex("subject")));
            emailBody.setText(cursor.getString(cursor.getColumnIndex("body")));
        }
        cursor.close();
    }

    private void saveEmailDraft() {
        String from = emailFrom.getText().toString();
        String to = emailTo.getText().toString();
        String cc = emailCc.getText().toString();
        String subject = emailSubject.getText().toString();
        String body = emailBody.getText().toString();

        // Save to database  
        if (emailId != -1) {
            dbHelper.insertData(from, to, cc, subject, body, false);
        } else {
            dbHelper.insertData(from, to, cc, subject, body, false);
        }
    }

    private boolean sendEmail() {
        // Here you can add your emailing logic  
        // For now, we'll just confirm sending with a Toast  
        // After sending, you might want to mark the email as sent in the database  

        dbHelper.updateEmailAsSent(emailId);
        return true; // Assume sending was successful  
    }

    private void deleteDraft() {
        if (emailId != -1) {
            dbHelper.deleteEmail(emailId);
        }
    }
}
*/
