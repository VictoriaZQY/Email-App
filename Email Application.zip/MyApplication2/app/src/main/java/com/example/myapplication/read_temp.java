package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class read_temp {
//    package com.example.myapplication;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//    public class EmailReadingActivity extends AppCompatActivity {
//
//        private TextView emailFrom, emailTo, emailCc, emailSubject, emailBody;
//        private Button editEmailButton, sendEmailButton;
//        private DatabaseHelper dbHelper;
//        private int emailId; // To hold the email ID for updating status
//        private static final int EDIT_EMAIL_REQUEST_CODE = 1; // Define request code
//
//        @Override
//        protected void onCreate(Bundle savedInstanceState) {
//            super.onCreate(savedInstanceState);
//            setContentView(R.layout.activity_email_reading);
//
//            dbHelper = new DatabaseHelper(this);
//
//            // Initialize TextViews
//            emailFrom = findViewById(R.id.email_from_reading);
//            emailTo = findViewById(R.id.email_to_reading);
//            emailCc = findViewById(R.id.email_cc_reading);
//            emailSubject = findViewById(R.id.email_subject_reading);
//            emailBody = findViewById(R.id.email_body_reading);
//            editEmailButton = findViewById(R.id.edit_email_button);
//            sendEmailButton = findViewById(R.id.send_email_button);
//
//            // Get data from Intent
//            Intent intent = getIntent();
//            emailId = intent.getIntExtra("email_id", -1); // Get the email ID
//            String from = intent.getStringExtra("from");
//            String to = intent.getStringExtra("to");
//            String cc = intent.getStringExtra("cc");
//            String subject = intent.getStringExtra("subject");
//            String body = intent.getStringExtra("body");
//
//            // Set the data to TextViews
//            emailFrom.setText("From: " + from);
//            emailTo.setText("To: " + (to != null ? to : ""));
//            emailCc.setText("CC: " + (cc != null ? cc : ""));
//            emailSubject.setText("Subject: " + (subject != null ? subject : ""));
//            emailBody.setText(body);
//
//
//            editEmailButton.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                /*// Send the current email data back for editing
//                Intent editIntent = new Intent(EmailReadingActivity.this, EmailCompositionActivity.class);
//                editIntent.putExtra("email_id", emailId);
//                editIntent.putExtra("from", from);
//                editIntent.putExtra("to", to);
//                editIntent.putExtra("cc", cc);
//                editIntent.putExtra("subject", subject);
//                editIntent.putExtra("body", body);
//                startActivityForResult(editIntent, EDIT_EMAIL_REQUEST_CODE); // Use startActivityForResult*/
//
//                    // Send the current email data back for editing
//                /*Intent editIntent = new Intent(EmailReadingActivity.this, EmailCompositionActivity.class);
//                editIntent.putExtra("email_id", emailId);
//                editIntent.putExtra("from", from);
//                editIntent.putExtra("to", to);
//                editIntent.putExtra("cc", cc);
//                editIntent.putExtra("subject", subject);
//                editIntent.putExtra("body", body);*/
//                    finish(); // return to the previous activity*/
//
//
//                }
//            });
//
//            sendEmailButton.setOnClickListener(view -> {
//                if (sendEmail()) {
//                    finish(); // Close this activity
//                    // After successfully sending, create a new draft
//                    Intent newEmail = new Intent(com.example.myapplication.EmailReadingActivity.this, EmailCompositionActivity.class);
//                    startActivity(newEmail); // Start a new email composition activity
//                } else {
//                    // Show fail message
//                    Toast.makeText(this, "Email sending failed. Please try again.", Toast.LENGTH_SHORT).show();
//                }
//            });
//        }
//
//        private boolean sendEmail() {
//
//            // logic to send the email
//
//            // mark it as sent in the database
//            boolean sent = dbHelper.updateEmailAsSent(emailId);
//            // Optionally display a Toast message to confirm sending
//            if (sent) {
//                // Show success message
//                Toast.makeText(this, "Email sent successfully!", Toast.LENGTH_SHORT).show();
//                return true; // Assume sending was successful
//            }
//            return false;
//        }
//    }
}
